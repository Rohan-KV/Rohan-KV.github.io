#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void staffMenu(char* className);
void addNewStudent(char* className);
void viewStudentsRecord(char* className);
void viewRemarks(char* className, char* username);
int validateStaffLogin(char* username, char* password, char* className);
int validateStudentLogin(char* username, char* className);
void studentMenu(char* className, char* username);
void viewRecord(char* className, char* username);
void headmasterMenu();
void addNewClassAndStaff();

void staffMenu(char* className) {
    int choice;
    do {
        printf("\nStaff Menu\n");
        printf("1. View Students Records\n");
        printf("2. Add New Student\n");
        printf("3. Logout\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                viewStudentsRecord(className);
                break;
            case 2:
                addNewStudent(className);
                break;
            case 3:
                printf("Logging out...\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
                break;
        }
    } while (choice != 3);
}

void viewRecord(char* className, char* username) {
    FILE* file;
    char filename[100], studentName[50];
    int studentRollNo;
    float studentMarks, studentAttendance;
    char remarks[256];
    int found = 0;

    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open class file.\n");
        exit(1);
    }

    printf("\nStudent Record for %s in %s:\n", username, className);
    printf("Name\tRoll No\tMarks\tAttendance\n");
    while (fscanf(file, "%s %d %f %f %[^\n]", studentName, &studentRollNo, &studentMarks, &studentAttendance, remarks) != EOF) {
        if (strcmp(username, studentName) == 0) {
            printf("%s\t%d\t%.2f\t%.2f\n", studentName, studentRollNo, studentMarks, studentAttendance);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("No record found for %s in %s.\n", username, className);
    }

    fclose(file);
}

void studentMenu(char* className, char* username) {
    int choice;
    do {
        printf("\nStudent Menu\n");
        printf("1. View My Record\n");
        printf("2. View My Remarks\n");
        printf("3. Log Out\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                viewRecord(className, username);
                break;
            case 2:
                viewRemarks(className, username);
                break;
            case 3:
                printf("Logging out...\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
                break;
        }
    } while (choice != 3);
}

void viewStudentsRecord(char* className) {
    FILE* file;
    char filename[100], studentName[50], remarks[256];
    int studentRollNo, rollNoToSearch;
    float studentMarks, studentAttendance;
    int found = 0;

    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open class file.\n");
        exit(1);
    }

    printf("\nEnter the roll number of the student you want to view: ");
    scanf("%d", &rollNoToSearch);

    while (fscanf(file, "%s %d %f %f %[^\n]", studentName, &studentRollNo, &studentMarks, &studentAttendance, remarks) != EOF) {
        if (studentRollNo == rollNoToSearch) {
            printf("\nStudent Record for Roll No %d in %s:\n", studentRollNo, className);
            printf("Name\tRoll No\tMarks\tAttendance\tRemarks\n");
            printf("%s\t%d\t%.2f\t%.2f\t%s\n", studentName, studentRollNo, studentMarks, studentAttendance, remarks);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("Student with roll number %d not found in %s.\n", rollNoToSearch, className);
    }

    fclose(file);
}

void viewRemarks(char* className, char* username) {
    FILE* file;
    char filename[100], studentName[50];
    char remarks[256];
    int studentRollNo;
    float studentMarks, studentAttendance;
    int found = 0;

    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open class file.\n");
        exit(1);
    }

    while (fscanf(file, "%s %d %f %f %[^\n]", studentName, &studentRollNo, &studentMarks, &studentAttendance, remarks) != EOF) {
        if (strcmp(username, studentName) == 0) {
            printf("\nYour Remarks:\n%s\n", remarks);
            found = 1;
            break;
        }
    }

    if (!found) {
        printf("No remarks found for %s.\n", username);
    }

    fclose(file);
}

void addNewStudent(char* className) {
    FILE* file;
    char name[50];
    int rollNo;
    float marks, attendance;
    char remarks[256];

    printf("\nEnter student details:\n");
    printf("Name: ");
    scanf("%s", name);
    printf("Roll No: ");
    scanf("%d", &rollNo);
    printf("Marks: ");
    scanf("%f", &marks);
    printf("Attendance Percentage: ");
    scanf("%f", &attendance);
    printf("Enter remarks: ");
    getchar(); 
    fgets(remarks, sizeof(remarks), stdin);

    char filename[100];
    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "a");

    if (file == NULL) {
        printf("Error: Unable to open class file.\n");
        exit(1);
    }

    fprintf(file, "%s %d %.2f %.2f %s", name, rollNo, marks, attendance, remarks);
    fclose(file);

    printf("Student added successfully to %s.\n", className);
}

void headmasterMenu() {
    int choice;
    do {
        printf("\nHeadmaster Menu\n");
        printf("1. Add New Class and Staff\n");
        printf("2. Log Out\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                addNewClassAndStaff();
                break;
            case 2:
                printf("Logging out...\n");
                break;
            default:
                printf("Invalid choice. Please enter a valid option.\n");
                break;
        }
    } while (choice != 2);
}

void addNewClassAndStaff() {
    FILE* file;
    char staffName[50], password[50], className[50];

    printf("\nEnter staff details:\n");
    printf("Enter staff name: ");
    scanf("%s", staffName);
    printf("Enter staff password: ");
    scanf("%s", password);
    printf("Enter class name: ");
    scanf("%s", className);

    file = fopen("data/staff.txt", "a");
    if (file == NULL) {
        printf("Error: Unable to open staff file.\n");
        exit(1);
    }

    fprintf(file, "%s %s %s\n", staffName, password, className);
    fclose(file);

    char filename[100];
    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "w"); 
    if (file == NULL) {
        printf("Error: Unable to create class file.\n");
        exit(1);
    }
    fclose(file);

    printf("New class '%s' and staff '%s' added successfully.\n", className, staffName);
}

int validateStaffLogin(char* username, char* password, char* className) {
    FILE* file;
    char fileUsername[50], filePassword[50], staffClass[50];
    file = fopen("data/staff.txt", "r");
    if (file == NULL) {
        printf("Error: Unable to open staff file.\n");
        exit(1);
    }
    while (fscanf(file, "%s %s %s", fileUsername, filePassword, staffClass) != EOF) {
        if (strcmp(username, fileUsername) == 0 && strcmp(password, filePassword) == 0) {
            fclose(file);
            strcpy(className, staffClass);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

int validateStudentLogin(char* username, char* className) {
    FILE* file;
    char fileUsername[50], studentClass[50];
    char filename[100];
    sprintf(filename, "data/%s students.txt", className);
    file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error: Unable to open students file.\n");
        exit(1);
    }
    while (fscanf(file, "%s %s", fileUsername, studentClass) != EOF) {
        if (strcmp(username, fileUsername) == 0) {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

int main() {
    int choice;
    char username[50], className[50], password[50];
    while (1) {
        printf("\nWelcome to Student Management System\n");
        printf("1. Student Login\n");
        printf("2. Staff Login\n");
        printf("3. Headmaster Login\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);
        switch (choice) {
            case 1:
                printf("Student Login selected\n");
                printf("Enter class: ");
                scanf("%s", className);
                printf("Enter username: ");
                scanf("%s", username);

                if (validateStudentLogin(username, className)) {
                    printf("Login successful!\n");
                    printf("You are in class: %s\n", className);
                    studentMenu(className, username);
                } else {
                    printf("Invalid username or class. Please try again.\n");
                }
                break;
            case 2:
                printf("Staff Login selected\n");
                printf("Enter username: ");
                scanf("%s", username);
                printf("Enter password: ");
                scanf("%s", password);

                if (validateStaffLogin(username, password, className)) {
                    printf("Login successful!\n");
                    printf("You are in class: %s\n", className);
                    staffMenu(className);
                } else {
                    printf("Invalid username or password. Please try again.\n");
                }
                break;
            case 3:
                printf("Headmaster Login selected\n");
                printf("Enter username: ");
                scanf("%s", username);
                printf("Enter password: ");
                scanf("%s", password);

                if (strcmp(username, "Sajai") == 0 && strcmp(password, "pass") == 0) {
                    printf("Login successful!\n");
                    headmasterMenu();
                } else {
                    printf("Invalid username or password. Please try again.\n");
                }
                break;
            case 4:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice. Please enter a valid option.\n");
        }
    }

    return 0;
}
